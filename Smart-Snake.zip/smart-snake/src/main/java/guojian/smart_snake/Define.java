package guojian.smart_snake;

public class Define {
	public static final byte BLANK = 0;
	public static final byte WALL = 1;
	public static final byte SNAKE = 2;
	public static final byte APPLE = 3;
	public static final byte PATH = 4;

}
