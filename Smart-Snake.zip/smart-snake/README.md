#smart-snake

运行环境: JDK1.8

java写的贪食蛇游戏，带简单ai，运行多次后可以出现吃满屏幕的情况。

运行App main方法

##### 点击zip下载
![输入图片说明](http://git.oschina.net/uploads/images/2016/1230/203801_d02c44da_403284.jpeg "在这里输入图片标题")


##### 导入到eclipse中
![输入图片说明](http://git.oschina.net/uploads/images/2016/1230/204006_9005d026_403284.jpeg "在这里输入图片标题")


